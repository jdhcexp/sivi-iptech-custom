Fix search filters *Active* and *Archived* to be working.
