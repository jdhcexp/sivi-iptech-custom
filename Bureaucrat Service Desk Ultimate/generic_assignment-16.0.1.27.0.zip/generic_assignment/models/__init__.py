from . import (
    generic_assign_policy_model,
    generic_assign_policy,
    generic_assign_policy_rule,
    ir_actions,
    ir_model,
)
