Added integration with server actions. So no, assignment policies could be easily run via server actions.
For example, with this update, you can easily change responsible user of lead, when lead's country is changed.
