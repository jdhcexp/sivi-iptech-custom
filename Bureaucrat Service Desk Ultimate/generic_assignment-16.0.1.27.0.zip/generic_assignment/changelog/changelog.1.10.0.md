- Improved assignment policy type *Assign by related policy*:
   - Added ability to sort filtered records by selected field
   - Added ability to choose sort order
   - Thus it is possible to select first record from sorted list, that could be
     used to assign to least loaded user
- Improved assignment policy type *User field*:
   - Now it is possible to search for user in Many2many and One2many fields
   - Added ability to select (random or first) user for field (one2many or many2many)
   - Added ability to filter user by conditions
   - Added ability to sort selected users before selection, thus it is possible to select for example least loaded user
