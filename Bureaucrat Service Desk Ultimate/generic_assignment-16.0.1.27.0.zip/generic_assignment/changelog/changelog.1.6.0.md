Added ability to add comment when assigning user via assign wizard
