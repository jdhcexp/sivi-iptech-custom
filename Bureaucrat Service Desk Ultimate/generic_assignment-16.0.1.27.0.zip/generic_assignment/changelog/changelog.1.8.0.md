- Added ability to assign multiple objects
- Added ability to dynamically create context action for target model.
  This makes it useful in such apps like CRM or Project.
