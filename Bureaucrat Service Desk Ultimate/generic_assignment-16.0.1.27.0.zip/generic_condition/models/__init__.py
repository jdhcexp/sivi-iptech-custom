from . import (
    generic_condition,
    generic_condition_domain_leaf,
    ir_model_fields,
)
