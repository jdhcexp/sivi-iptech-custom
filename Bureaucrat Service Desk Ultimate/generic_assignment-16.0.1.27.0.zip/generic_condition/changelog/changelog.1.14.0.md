Added support for date and datetime field in Simple Field checks:
- check if field value equal or not equal to specific value
- check if field value is set or not set
