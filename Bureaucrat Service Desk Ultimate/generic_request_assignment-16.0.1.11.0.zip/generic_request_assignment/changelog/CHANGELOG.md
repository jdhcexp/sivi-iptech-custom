# Changelog

## Version 1.5.0

- Added menu for assigment policies related to requests inside Requests top menu


