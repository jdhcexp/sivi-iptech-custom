from . import generic_service
from . import generic_service_level
from . import res_partner
from . import res_config_settings
from . import generic_service_group
