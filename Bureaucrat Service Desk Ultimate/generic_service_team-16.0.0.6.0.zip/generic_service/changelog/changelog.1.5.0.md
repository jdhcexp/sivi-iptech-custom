Added menu 'Settings' and 'Services' settings
