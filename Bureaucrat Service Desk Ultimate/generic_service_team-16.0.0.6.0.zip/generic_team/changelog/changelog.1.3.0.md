[FIX] show user teams only for users that has 'Generic Team User (implicit)' group
