from odoo.addons.generic_request.tests import test_access_rights
from . import test_event_action
