# Changelog

## Version 0.0.11

- updated tests and demo data according to new priority (1...5)


