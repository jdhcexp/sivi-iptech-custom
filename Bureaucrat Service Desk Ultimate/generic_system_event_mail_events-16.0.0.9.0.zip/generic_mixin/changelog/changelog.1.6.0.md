Added `pre_write` and `post_write` decorators.
