Generic System Event (Mail Events)
==================================
