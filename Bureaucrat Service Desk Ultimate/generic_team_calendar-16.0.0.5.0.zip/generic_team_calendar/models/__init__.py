from . import generic_team
