Added new `generic_mixin.tools.xmlid` module, that contains utility functions
to manage xmlid. These functions are mostly useful for migration scripts
to manipulate xmlids.
