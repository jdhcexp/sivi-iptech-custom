Added support for [jinja2](http://jinja.pocoo.org) templates for subrequest text
