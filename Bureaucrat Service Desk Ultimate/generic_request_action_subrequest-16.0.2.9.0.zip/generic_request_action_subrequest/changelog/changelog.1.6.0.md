Added ability to forward deadline to subrequest when it is created via automated action
