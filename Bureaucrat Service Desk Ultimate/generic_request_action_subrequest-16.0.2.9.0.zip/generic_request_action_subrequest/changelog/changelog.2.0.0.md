Use *Request Creation Templates* to create subrequests.
This way it would be possible to create subrequest with
specific service or tags without extra integration modules.
