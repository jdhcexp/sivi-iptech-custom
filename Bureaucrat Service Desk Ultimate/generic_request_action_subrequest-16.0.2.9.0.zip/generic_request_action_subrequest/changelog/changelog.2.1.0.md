Added feature *Transfer Fields to Subrequest*,
that allows to configure what fields have to be transfered directly
from parent request to subrequest created by action *Subrequest*.
