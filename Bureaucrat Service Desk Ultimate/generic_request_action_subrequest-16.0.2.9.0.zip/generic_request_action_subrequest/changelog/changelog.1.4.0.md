Add ability to transfer author of parent request to subrequest.
