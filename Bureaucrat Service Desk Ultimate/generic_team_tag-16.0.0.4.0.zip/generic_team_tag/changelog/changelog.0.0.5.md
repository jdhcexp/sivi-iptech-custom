Display team-member's tags on user form
