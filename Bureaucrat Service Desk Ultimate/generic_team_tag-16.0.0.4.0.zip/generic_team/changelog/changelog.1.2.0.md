Show user teams on user form
