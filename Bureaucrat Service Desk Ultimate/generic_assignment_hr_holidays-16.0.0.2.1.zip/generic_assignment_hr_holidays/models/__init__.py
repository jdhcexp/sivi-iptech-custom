from . import generic_assign_policy_rule
