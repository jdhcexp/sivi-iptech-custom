from . import generic_wizard_assignment
