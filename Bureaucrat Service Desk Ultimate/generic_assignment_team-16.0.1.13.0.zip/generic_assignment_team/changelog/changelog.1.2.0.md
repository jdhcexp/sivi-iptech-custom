Improved the way to select team members:
    - now it is possible to filter team members with conditions before selection
    - now it is possible to sort team member before selection, for example to choose first team member with minimum assigned open requests.
    - now it is possible to choose selection type: random or first.
