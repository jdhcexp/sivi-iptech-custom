Updated to be compatible with changed type of relation between task and request

---

Added support for [jinja2](http://jinja.pocoo.org/) templating
