Added ability to user request's deadline for a task created via automated action
